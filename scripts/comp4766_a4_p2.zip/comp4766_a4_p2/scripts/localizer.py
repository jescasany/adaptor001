#!/usr/bin/env python

"""
The Localizer node provides the connectivity between sensors, the GUI, and the
Bayes Filter class (this node instantiates a BayesFilter object).  This class
also publishes the belief representation stored within BayesFilter so that it
can be viewed in RViz.
"""

import roslib
roslib.load_manifest('comp4766_a4_p2')
import rospy
import random
import math
from bayes_filter import BayesFilter

from comp4766_a4_p2.msg import WallScan
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker

class Localizer:

    # Constants
    NUM_STATES = 20
    FORWARD_SPEED_MPS = 1.0
    ROTATE_SPEED_RADPS = math.pi / 2
    UPPER_NOISE_THRESHOLD = 0.9
    LOWER_NOISE_THRESHOLD = 0.1

    def __init__(self):
        """
        Construst a new Localizer object and hook up this ROS node
        to the simulated robot's velocity control and laser topics
        """
        self.rotateDuration = 1.85
        self.moveDuration = 0.75

        # Initialize random time generator
        random.seed(0)

        # Create publisher for the simulated robot's velocity command
        self.command_pub = rospy.Publisher('/cmd_vel', Twist)

        # Subscribe to wall_scan and set wall_scan_callback as the callback.
        self.wall_sub = rospy.Subscriber('/wall_scan', WallScan, \
                                         self.wall_scan_callback)

        # Subscribe to the action topic which is set by 'controller'
        self.action_sub = rospy.Subscriber('/action', Int32, \
                                           self.action_callback)

        # Publisher for the MarkerArray used to show beliefs
        self.marker_pub = rospy.Publisher('/beliefs', MarkerArray)

        # Parameters
        self.movenoise = False;
        self.measnoise = False;
        print "Movement noise: {}".format(self.movenoise)
        print "Measurement noise: {}".format(self.measnoise)

        # Create the BayesFilter object which stores and manipulates our
        # belief representation.
        self.bayes_filter = BayesFilter(Localizer.NUM_STATES)
 
    def publish_belief_markers(self):
        """Publish visual information to RVIZ of the beliefstates."""

        belief_states = self.bayes_filter.get_belief()

        marker_array = MarkerArray()
        for i in range(Localizer.NUM_STATES):
            marker = Marker()
            marker.header.frame_id = '/map'
            marker.header.stamp = rospy.Time()
            marker.ns = 'beliefs'
            marker.type = Marker.CUBE
            marker.action = Marker.ADD
            if i >= 10:
                marker.pose.position.x = -0.8
                marker.pose.position.y =  4.5 -i % 10
            else:
                marker.pose.position.x = 0.8;
                marker.pose.position.y = -4.5 + i

            marker.pose.position.z = 0.2
            marker.pose.orientation.x = 0.0
            marker.pose.orientation.y = 0.0
            marker.pose.orientation.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.5
            marker.scale.y = 1.0
            marker.scale.z = 1.0
            # Set the color -- be sure to set alpha to something non-zero!
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.0
            marker.color.a = 1.0  * belief_states[i]
            marker.id = i
            marker_array.markers.append(marker)

            #Text
            marker2 = Marker()
            marker2.header.frame_id = '/map'
            marker2.header.stamp = rospy.Time()
            marker2.ns = 'beliefs'
            marker2.type = Marker.TEXT_VIEW_FACING
            marker2.action = Marker.ADD
            if i >= 10:
                marker2.pose.position.x = -0.8
                marker2.pose.position.y =  4.5 -i % 10
            else:
                marker2.pose.position.x = 0.8
                marker2.pose.position.y = -4.5 + i
            marker2.pose.position.z = 0.2
            marker2.pose.orientation.x = 0.0
            marker2.pose.orientation.y = 0.0
            marker2.pose.orientation.z = 0.0
            marker2.pose.orientation.w = 1.0
            marker2.scale.x = 0.5
            marker2.scale.y = 1.0
            marker2.scale.z = 0.15
            # Set the color -- be sure to set alpha to something non-zero!
            marker2.color.r = 1.0
            marker2.color.g = 1.0
            marker2.color.b = 1.0
            marker2.color.a = 1.0
            marker2.text = "State: " + str(i) + "\nBelief:\n" + \
                           str(belief_states[i])
            marker2.id = Localizer.NUM_STATES + i
            marker_array.markers.append(marker2);    

        self.marker_pub.publish(marker_array)

    def move(self, linearVelMPS, angularVelRadPS):
        """Send a velocity command."""

        twist = Twist()
        twist.linear.x = linearVelMPS
        twist.angular.z = angularVelRadPS
        self.command_pub.publish(twist)

    def movement_noise(self):
        """introduce discrete movement noise"""

        if (self.movenoise):
            value = random.random()
            if value < Localizer.LOWER_NOISE_THRESHOLD:
                return 0
            if value >= Localizer.UPPER_NOISE_THRESHOLD:
                return 2
        return 1

    def measurement_noise(self, measurement):
        """Introduce measurement noise""" 
        if (self.measnoise):
            value = random.random()
            if measurement:
                if value <= 0.2:
                    return not measurement
            else:
                if value <= 0.3:
                    return not measurement
        return measurement

    def action_callback(self, action_msg):
        """Process the incoming action message"""

        if action_msg.data == 0:
            # Forwards movement
            steps = self.movement_noise()
            print "Executing forward movement by {} steps".format(steps)
            for i in range(steps):
                if not self.obstacle:
                    moveStartTime = rospy.get_time()
                    while rospy.get_time() - moveStartTime <= self.moveDuration:
                        self.move(self.FORWARD_SPEED_MPS, 0)
                        rospy.sleep(0.2)
                else:
                    print "Not moving because of obstacle."
            self.bayes_filter.prediction(True)

        if action_msg.data == 1:
            # 180 degree turn
            value = 0
            if self.movenoise:
                value = random.random()
            if value <= 0.9:
                print "Executing 180 degree turn"
                # 90% of the time we actually execute the turn.
                rotateStartTime = rospy.get_time()
                while rospy.get_time() - rotateStartTime <= self.rotateDuration:
                    self.move(0, Localizer.ROTATE_SPEED_RADPS)
                    rospy.sleep(0.02)
            self.bayes_filter.prediction(False)

        if action_msg.data == 2:
            # Apply measurement update
            self.bayes_filter.meas_update(self.wall_left, self.wall_right)

        if action_msg.data == 3:
            # Toggle movement noise
            self.movenoise = not self.movenoise
            print "Movement noise: {}".format(self.movenoise)

        if action_msg.data == 4:
            # Toggle measurement noise
            self.measnoise = not self.measnoise
            print "Measurement noise: {}".format(self.measnoise)

        self.publish_belief_markers()

    def wall_scan_callback(self, wall_scan_msg):
        """Process the incoming wall scan message"""
        self.wall_left = self.measurement_noise(wall_scan_msg.wall_left)
        self.wall_right = self.measurement_noise(wall_scan_msg.wall_right)
        self.obstacle = wall_scan_msg.wall_front

if __name__ == '__main__':
    rospy.init_node('localizer')
    bf = Localizer()
    rospy.spin()
