#!/usr/bin/env python

"""
Implementation of Bayes Filter for our corridor confined robot.

MESSAGE TO STUDENTS (ALL CAPS): YOUR JOB IS TO FILL IN ALL METHODS THAT ARE
NOT ALREADY PROVIDED.  YOU SHOULD FEEL FREE TO CREATE ADDITIONAL HELPER METHODS
IF REQUIRED.

Student Name: INSERT YOUR NAME HERE
Student Number: INSERT YOUR STUDENT NUMBER HERE
"""

import roslib
roslib.load_manifest('comp4766_a4_p2')
import rospy
import math

from comp4766_a4_p2.msg import WallScan

class BayesFilter:

    def __init__(self, number_belief_states):
        # We will stick with a 20 state belief representation.
        assert number_belief_states == 20
        self.n = number_belief_states

        # Initialize belief to the uniform distribution
        self.belief_states = []
        uniform_value = 1.0 / self.n
        for i in range(self.n):
            self.belief_states.append(uniform_value); 

        # ADD OTHER NECESSARY INITIALIZATIONS HERE (E.G. SOME KIND OF MAP!)

    def get_belief(self):
        """Returns an array of 20 floating point values describing the
           current belief state."""
        # THERE SHOULD BE NO NEED TO MODIFY THIS
        return self.belief_states
 
    def prediction(self, forwards):
        """Apply the prediction step of Bayes Filter.

        If 'forwards' is True then the motion consists of a forward movement.
        Otherwise, it consists of a 180 degree turn.

        This method takes 'belief_states' as being the belief from the last time
        step and updates 'belief_states' to contain the prediction (i.e.
        bel-bar)."""

        # INSERT YOUR IMPLEMENTATION HERE

    def meas_update(self, wall_left, wall_right):
        """Apply the measurement update step of Bayes Filter.

        This method takes 'belief_states' as being the prediction from a
        previous motion and updates 'belief_states' to contain the new belief.

        wall_left -- If true there is a wall on the robot's left;  If false
                     there is a door
        wall_right -- If true there is a wall on the robot's right;  If false
                      there is a door
        """

        # INSERT YOUR IMPLEMENTATION HERE

