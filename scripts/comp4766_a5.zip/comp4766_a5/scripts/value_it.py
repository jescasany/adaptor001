"""
Implementation of the Value Iteration algorithm for planning the path of a
robot to a desired goal in a 2-D discretized grid.

MESSAGE TO STUDENTS (ALL CAPS): YOUR JOB IS TO FILL IN THE value_it FUNCTION.
YOU SHOULD FEEL FREE TO CREATE ADDITIONAL HELPER FUNCTIONS IF REQUIRED.  

Student Name: INSERT YOUR NAME HERE
Student Number: INSERT YOUR STUDENT NUMBER HERE
"""

import random

# INSERT ANY OTHER NECESSARY IMPORTS HERE

from comp4766_a5.msg import Position
from comp4766_a5.msg import Move

# INSERT ANY OTHER MESSAGES/SERVICES HERE

def value_it(occupancy_grid, goal_x, goal_y):
    """Apply the value iteration algorithm for the given map and goal.

    Given an occupancy grid and a goal location, apply value iteration which
    will yield the tuple (policies, values).  Both are 2-D lists with the same
    dimensions as the map.  policies will store a Move() message at every
    position whereas values stores floats.
    """

    # INSERT YOUR IMPLEMENTATION HERE (YOU SHOULD PROBABLY DEFINE SOME HELPER
    # FUNCTIONS).

    # Uncomment the following just for a quick-and-dirty test to see if the
    # overall system is running.
    #
    #width = occupancy_grid.info.width
    #height = occupancy_grid.info.height
    #values = [[random.random() for j in range(height)] \
    #           for i in range(width)]
    #
    #policies = [[Move(random.randint(1,9)) for j in range(height)] \
    #             for i in range(width)]
    #
    #return policies, values
