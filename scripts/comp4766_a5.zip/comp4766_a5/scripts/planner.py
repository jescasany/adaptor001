#!/usr/bin/env python  

"""
Implements probabilistic planning based on value iteration.  Subscribes to the
/goal_pos topic and publishes /cmd_move.  Visualization information is output on the /value_markers and /policy_markers topics.
"""

import roslib
roslib.load_manifest('comp4766_a5')
import rospy
import random
from utils import apply_move
from value_it import value_it

from comp4766_a5.msg import Position
from comp4766_a5.msg import Move
from nav_msgs.msg import OccupancyGrid
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from geometry_msgs.msg import PoseStamped

class Planner:
    def __init__(self):
        # Controls whether or not the plan should actually be computed.  This
        # will be set to True only upon updates to /map or /goal_pos.
        self.update = False

        self.pos = None
        self.goal_pos = None

        rospy.init_node('planner')

        # Subscribe to the map
        rospy.Subscriber('/map', OccupancyGrid, self.map_callback)

        # Subscribe to the /pos topic
        rospy.Subscriber('/pos', Position, self.pos_callback)

        # Subscribe to the /goal_pos topic
        rospy.Subscriber('/goal_pos', PoseStamped, self.goal_pos_callback)

        # Create a publisher to output the desired movement
        self.cmd_move_publisher = rospy.Publisher('/cmd_move', Move)

        # Create publishers for the value function and for the policy.
        self.value_marker_publisher = rospy.Publisher('/value_markers', \
                                                      MarkerArray, latch=True)
        self.policy_marker_publisher = rospy.Publisher('/policy_markers', \
                                                       MarkerArray, latch=True)

    def map_callback(self, msg):
        self.occupancy_grid = msg
        self.width = self.occupancy_grid.info.width
        self.height = self.occupancy_grid.info.height

        self.values = [[0 for j in range(self.height)] \
                      for i in range(self.width)]
        self.policy = [[Move() for j in range(self.height)] \
                      for i in range(self.width)]
        self.update = True

    def pos_callback(self, msg):
        self.pos = msg
        
    def goal_pos_callback(self, msg):
        self.goal_pos = msg
        self.update = True

    def publish_value_markers(self):

        # Normalize the values displayed by finding the maximum, minimum, and
        # applying the following to yield a number in the range [0, 1].
        #  (value - min) / (max - min)
        normalize = True
        max_value = max(max(column) for column in self.values)
        min_value = min(min(column) for column in self.values)
        if max_value == min_value:
            normalize = False

        marker_array = MarkerArray()
        index = 0
        for x in range(self.width):
            for y in range(self.height):
                marker = Marker()
                marker.header.frame_id = '/map'
                marker.header.stamp = rospy.Time()
                marker.ns = 'value_markers'
                marker.id = index
                marker.type = Marker.CUBE
                marker.action = Marker.ADD

                marker.pose.position.x = x + 0.5
                marker.pose.position.y = y + 0.5

                marker.scale.x = 1.0
                marker.scale.y = 1.0
                marker.scale.z = 1.0

                # Set colour
                marker.color.r = 0.0
                marker.color.g = 0.0
                marker.color.b = 1.0
                if normalize:
                    marker.color.a = (self.values[x][y] - min_value) / \
                                     (max_value - min_value)
                else:
                    marker.color.a = 0

                marker_array.markers.append(marker)
                index += 1

        self.value_marker_publisher.publish(marker_array)

    def publish_policy_markers(self):
        marker_array = MarkerArray()
        index = 0
        for x in range(self.width):
            for y in range(self.height):
                if self.policy[x][y].direction == 0:
                    # No point in drawing an arrow that's pointing nowhere
                    continue
                marker = Marker()
                marker.header.frame_id = '/map'
                marker.header.stamp = rospy.Time()
                marker.ns = 'policy_markers'
                marker.id = index
                marker.type = Marker.ARROW
                marker.action = Marker.ADD

                dx, dy = apply_move(Position(), self.policy[x][y])
                marker.points.append(Point(x + 0.5, y + 0.5, 0))
                marker.points.append(Point(x + 0.5*dx + 0.5, \
                                           y + 0.5*dy + 0.5, \
                                           0))

                marker.scale.x = 0.2
                marker.scale.y = 0.4
                marker.scale.z = 0.3

                marker.color.r = 1.0
                marker.color.g = 0.0
                marker.color.b = 0.0
                marker.color.a = 1.0

                marker_array.markers.append(marker)
                index += 1

        self.policy_marker_publisher.publish(marker_array)

    def compute_plan(self):
        if self.goal_pos == None:
            return

        goal_x = int(self.goal_pos.pose.position.x)
        goal_y = int(self.goal_pos.pose.position.y)
        rospy.loginfo('goal_x: {}, goal_y: {}'.format(goal_x, goal_y))
        self.policy, self.values = value_it(self.occupancy_grid, goal_x, goal_y)

        self.update = False
        rospy.loginfo("planner: Plan updated")

    def move(self):
        if self.pos == None:
            # We don't know our position yet.
            return

        # Consult the policy and execute the commanded movement.
        x = int(self.pos.x)
        y = int(self.pos.y)
        move = self.policy[x][y]
        self.cmd_move_publisher.publish(move)

    def loop(self):
        # The loop below executes planning.  Its important that we are not tied
        # to the simulation's loop since planning is a potentially expensive
        # operation (of course, so are simulation and movement).  By keeping
        # these processes separate they can each proceed at their own rates.
        r = rospy.Rate(5)
        while not rospy.is_shutdown():
            if self.update:
                self.compute_plan()
                self.publish_value_markers()
                self.publish_policy_markers()
            self.move()
            r.sleep()

if __name__ == '__main__':
    planner = Planner()
    planner.loop()
